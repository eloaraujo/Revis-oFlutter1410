package com.example.flutterrevisao1410

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
